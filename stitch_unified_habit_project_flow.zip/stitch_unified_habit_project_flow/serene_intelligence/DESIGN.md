---
name: Serene Intelligence
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#474556'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#787588'
  outline-variant: '#c8c4d9'
  surface-tint: '#5638f3'
  primary: '#451de3'
  on-primary: '#ffffff'
  primary-container: '#5e43fb'
  on-primary-container: '#e7e2ff'
  inverse-primary: '#c6bfff'
  secondary: '#006688'
  on-secondary: '#ffffff'
  secondary-container: '#00c1fd'
  on-secondary-container: '#004b65'
  tertiary: '#4b4f52'
  on-tertiary: '#ffffff'
  tertiary-container: '#63676a'
  on-tertiary-container: '#e3e6e9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c6bfff'
  on-primary-fixed: '#160066'
  on-primary-fixed-variant: '#3c03dd'
  secondary-fixed: '#c2e8ff'
  secondary-fixed-dim: '#75d1ff'
  on-secondary-fixed: '#001e2b'
  on-secondary-fixed-variant: '#004d67'
  tertiary-fixed: '#e0e3e6'
  tertiary-fixed-dim: '#c3c7ca'
  on-tertiary-fixed: '#181c1e'
  on-tertiary-fixed-variant: '#43474a'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  h1:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  margin-page: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is built on a foundation of **Calm Minimalism** with a "smart assistant" personality. The aesthetic prioritizes cognitive ease, utilizing generous whitespace and a reductive approach to UI elements to ensure the user feels organized and encouraged rather than overwhelmed.

The style blends **Modern Corporate** precision with **Glassmorphism** hints. It uses soft, layered surfaces to create a sense of digital spatiality. The interface should feel like a quiet, high-end workspace—unobtrusive when idle, yet vibrant and motivating when the user engages with their goals.

## Colors

The palette is designed to balance tranquility with high-energy focus. 
- **Backgrounds:** Use a "Paper" logic—off-whites and extremely light cool grays (#F8F9FB) to reduce eye strain.
- **Accents:** A deep, regal purple serves as the primary driver for action and focus. A vibrant "electric" blue is used for progress and motivational feedback.
- **Status:** Use soft, desaturated versions of green and amber for low-friction notifications.
- **Contrast:** High-contrast dark charcoal (#1A1C1E) is reserved strictly for primary text to ensure maximum legibility.

## Typography

This design system utilizes **Manrope** for headings to provide a modern, slightly geometric warmth, while **Inter** handles body copy for its exceptional legibility on mobile screens.

Hierarchy is established through weight and scale rather than color. Important headers use tight letter spacing and bold weights, while body text uses generous line heights to facilitate easy scanning. Labels and small metadata should always be uppercase with slight letter spacing to maintain clarity at small scales.

## Layout & Spacing

The layout follows a **Fluid Grid** model optimized for thumb-reachability. 
- **Margins:** 24px horizontal margins provide a "breathing room" frame for content.
- **Vertical Rhythm:** A strict 4px/8px baseline grid ensures consistent vertical stacking. 
- **The "Safe Zone":** Primary interactions (FABs, Navigation) are clustered in the bottom 30% of the screen. 
- **Negative Space:** Use "Stack-LG" (32px) between unrelated content sections to prevent visual clutter.

## Elevation & Depth

This design system uses **Ambient Shadows** and **Tonal Layering** to define hierarchy. 
- **Level 0 (Background):** Solid off-white (#F8F9FB).
- **Level 1 (Cards/Surface):** Pure white (#FFFFFF) with a very soft, diffused shadow (0px 8px 24px, 4% opacity of primary color).
- **Level 2 (Floating/Active):** Higher elevation with a dual shadow (one sharp, one soft) to indicate interactivity.
- **Glassmorphism:** Use backdrop blurs (20px-30px) on top navigation bars and bottom sheets to maintain context of the underlying content.

## Shapes

The shape language is defined by **large, friendly radii**. 
- **Default Buttons/Cards:** 16px (1rem) corner radius.
- **Large Containers/Bottom Sheets:** 24px (1.5rem) corner radius on top edges.
- **Interactive Small Elements (Chips):** Fully rounded (Pill-shaped).
This softness communicates a non-aggressive, helpful personality that feels "smart" and modern.

## Components

- **Floating Action Button (FAB):** The primary driver for "New Task" or "Quick Log." It should be large, circular, and use a gradient of the primary purple and secondary blue. 
- **Bottom Navigation:** Uses a frosted glass (blur) background. Active states are indicated by a small dot or a subtle tonal shift, rather than heavy icons.
- **Informative Cards:** Must contain a header, a summary line, and a secondary blue progress bar if applicable. Cards should never have borders—only soft shadows.
- **Progress Bars:** Use a thick (8px+) stroke with rounded caps. The track is a light gray, and the fill is a vibrant blue gradient.
- **Input Fields:** Use "Ghost" styling—no heavy borders. A light gray fill that transforms into a thin purple bottom-border when focused.
- **Thumb-Friendly Lists:** Vertical list items must have a minimum height of 56px to ensure easy tapping without precision errors.